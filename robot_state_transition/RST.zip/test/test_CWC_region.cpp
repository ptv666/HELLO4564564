/*
 * @Author: ptw 1515901920@qq.com
 * @Date: 2023-03-17 19:07:42
 * @LastEditors: ptw 1515901920@qq.com
 * @LastEditTime: 2023-03-17 20:55:30
 * @FilePath: /robot_state_transition/test/test_CWC_region.cpp
 * @Description:
 */
#include "Bretl.hh"
#include "solve_LP_GLPK.hh"
#include <boost/test/included/unit_test.hpp>
#include <time.h>  //时间
#include <iomanip> //规范化输出信息

BOOST_AUTO_TEST_SUITE(test_CWC)

BOOST_AUTO_TEST_CASE(test_01)
{
    // debug测试时间
    // if (std::cout << "准备执行第一步:\n" && std::getline(std::cin, str_temp))
    // {
    //     std::cout << "开始执行" << std::endl;
    // }
    clock_t start1, end1;
    start1 = clock();

    Robot_State_Transition::MatrixXX Contacts(4, 3), Normals(4, 3);
    Contacts << 0.3, 0.2, -0.4,
        0.3, -0.2, -0.4,
        -0.3, 0.2, -0.4,
        -0.3, -0.2, -0.4;
    Normals << 0, 0, 1,
        0, 0, 1,
        0, 0, 1,
        0, 0, 1;
    double mass = 45;
    double mu = 0.5;

    auto Vertices = Robot_State_Transition::comput_friction_region(Contacts, Normals, mu, mass);

    end1 = clock(); // 计算第一阶段的时间
    std::cout << "四个简单接触点用时:\t" << std::setprecision(8) << (double)(end1 - start1) / CLOCKS_PER_SEC << std::endl;
    std::cout << Vertices << std::endl;
}

BOOST_AUTO_TEST_CASE(test_02)
{
    clock_t start1, end1;
    start1 = clock();

    Robot_State_Transition::MatrixXX Contacts(4, 3), Normals(4, 3);
    Contacts << 0.3, 0.2, -0.4,
        0.3, -0.2, -0.4,
        -0.3, 0.2, -0.4,
        -0.3, -0.2, -0.4;
    Normals << 0, (double)-1 / 2, sqrt(3) / 2,
        0, 0, 1,
        0, (double)-1 / 2, sqrt(3) / 2,
        0, 0, 1;
    double mass = 45;
    double mu = 0.5;

    auto Vertices = Robot_State_Transition::comput_friction_region(Contacts, Normals, mu, mass);

    end1 = clock(); // 计算第一阶段的时间
    std::cout << "四个稍微复杂接触点用时:\t" << std::setprecision(8) << (double)(end1 - start1) / CLOCKS_PER_SEC << std::endl;
    std::cout << Vertices << std::endl;
}


BOOST_AUTO_TEST_SUITE_END()